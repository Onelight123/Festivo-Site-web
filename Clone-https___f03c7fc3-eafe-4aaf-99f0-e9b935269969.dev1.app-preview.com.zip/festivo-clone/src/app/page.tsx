"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

export default function Home() {
  const [mounted, setMounted] = useState(false);

  // Handle animation mounting
  useEffect(() => {
    setMounted(true);
  }, []);

  const animationClass = mounted ? 'opacity-100' : 'opacity-0';

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className={`text-center mb-20 ${animationClass} transition-opacity duration-500`}>
          <div className="inline-flex items-center mb-8 glass rounded-full px-6 py-2">
            <Image src="/crown.svg" width={20} height={20} alt="Crown" className="mr-2" priority />
            <span className="text-purple-400 font-medium">Bot Discord Premium</span>
          </div>
          <h1 className="text-7xl font-bold mb-6 text-gradient">Festivo</h1>
          <p className="text-2xl text-purple-200/60">Élevez votre expérience Discord</p>
        </header>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {/* Moderation Card */}
          <div className={`glass rounded-2xl p-8 hover-glow transition-all duration-500 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.1s' }}>
            <div className="flex items-center mb-6">
              <Image src="/shield.svg" width={24} height={24} alt="Shield" priority />
              <h2 className="text-2xl font-semibold ml-3">Modération</h2>
            </div>
            <p className="text-purple-200/60 mb-6 text-sm">Outils puissants pour maintenir votre serveur en sécurité</p>
            <div className="space-y-3">
              <CommandButton command="/ban" description="Bannir un membre" />
              <CommandButton command="/kick" description="Expulser un membre" />
              <CommandButton command="/mute" description="Réduire au silence" />
              <CommandButton command="/warn" description="Avertir un membre" />
              <CommandButton command="/clear" description="Nettoyer le chat" />
            </div>
          </div>

          {/* Configuration Card */}
          <div className={`glass rounded-2xl p-8 hover-glow transition-all duration-500 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.2s' }}>
            <div className="flex items-center mb-6">
              <Image src="/settings.svg" width={24} height={24} alt="Settings" priority />
              <h2 className="text-2xl font-semibold ml-3">Configuration</h2>
            </div>
            <p className="text-purple-200/60 mb-6 text-sm">Personnalisez les paramètres de votre serveur</p>
            <div className="space-y-3">
              <CommandButton command="/setup" description="Configuration des salons" />
              <CommandButton command="/autorole" description="Rôle automatique" />
              <CommandButton command="/badwords" description="Mots interdits" />
            </div>
          </div>

          {/* Welcome System Card */}
          <div className={`glass rounded-2xl p-8 hover-glow transition-all duration-500 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center mb-6">
              <Image src="/user.svg" width={24} height={24} alt="User" priority />
              <h2 className="text-2xl font-semibold ml-3">Système d&apos;Accueil</h2>
            </div>
            <p className="text-purple-200/60 mb-6 text-sm">Système complet d&apos;accueil et de sécurité</p>
            <div className="space-y-3">
              <CommandButton command="/welcome" description="Message personnalisé" />
              <CommandButton command="/captcha" description="Vérification humaine" />
              <CommandButton command="/antiraid" description="Protection serveur" />
            </div>
          </div>

          {/* Utilities Card */}
          <div className={`glass rounded-2xl p-8 hover-glow transition-all duration-500 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.4s' }}>
            <div className="flex items-center mb-6">
              <Image src="/chat.svg" width={24} height={24} alt="Chat" priority />
              <h2 className="text-2xl font-semibold ml-3">Utilitaires</h2>
            </div>
            <p className="text-purple-200/60 mb-6 text-sm">Outils essentiels pour votre communauté</p>
            <div className="space-y-3">
              <CommandButton command="/userinfo" description="Info membre" />
              <CommandButton command="/report" description="Signaler" />
              <CommandButton command="/annonce" description="Faire une annonce" />
            </div>
          </div>
        </div>

        {/* Secondary Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {/* Real-time Alerts */}
          <div className={`glass rounded-2xl p-8 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.5s' }}>
            <div className="flex items-center mb-4">
              <Image src="/bell.svg" width={24} height={24} alt="Bell" priority />
              <h3 className="text-2xl font-semibold ml-3">Alertes en Temps Réel</h3>
            </div>
            <p className="text-purple-200/60">Notifications instantanées pour toutes les actions de modération</p>
          </div>

          {/* Advanced Security */}
          <div className={`glass rounded-2xl p-8 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center mb-4">
              <Image src="/lock.svg" width={24} height={24} alt="Lock" priority />
              <h3 className="text-2xl font-semibold ml-3">Sécurité Avancée</h3>
            </div>
            <p className="text-purple-200/60">Protection anti-raid et système de vérification</p>
          </div>

          {/* Contests */}
          <div className={`glass rounded-2xl p-8 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.7s' }}>
            <div className="flex items-center mb-4">
              <Image src="/gift.svg" width={24} height={24} alt="Gift" priority />
              <h3 className="text-2xl font-semibold ml-3">Concours</h3>
            </div>
            <p className="text-purple-200/60">Créez et gérez des concours engageants</p>
          </div>
        </div>

        {/* Bot Statistics */}
        <div className={`glass rounded-2xl p-10 animate-fadeInUp opacity-0 ${mounted ? 'opacity-100' : ''}`} style={{ animationDelay: '0.8s' }}>
          <div className="flex items-center mb-8">
            <Image src="/stats.svg" width={28} height={28} alt="Stats" priority />
            <h3 className="text-3xl font-semibold ml-4">Statistiques du Bot</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="glass rounded-xl p-8 text-center border-gradient">
              <p className="text-4xl font-bold text-gradient">9</p>
              <p className="text-purple-200/60 mt-3">Serveurs</p>
            </div>
            <div className="glass rounded-xl p-8 text-center border-gradient">
              <p className="text-4xl font-bold text-gradient">15</p>
              <p className="text-purple-200/60 mt-3">Commandes</p>
            </div>
            <div className="glass rounded-xl p-8 text-center border-gradient">
              <p className="text-4xl font-bold text-gradient">24/7</p>
              <p className="text-purple-200/60 mt-3">Support</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Command Button Component
function CommandButton({ command, description }: { command: string; description: string }) {
  return (
    <button className="inline-flex items-center rounded-md text-sm font-medium ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border hover:text-accent-foreground h-10 px-4 py-2 w-full justify-start bg-purple-900/20 hover:bg-purple-900/30 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300">
      {command}
      <span className="ml-auto text-xs text-purple-300/60">{description}</span>
    </button>
  );
}
